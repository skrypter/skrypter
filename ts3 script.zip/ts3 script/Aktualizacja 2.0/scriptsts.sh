#!/bin/bash
# Colors
ESC_SEQ="\x1b["
COL_RESET=$ESC_SEQ"39;49;00m"
COL_RED=$ESC_SEQ"31;01m"
COL_GREEN=$ESC_SEQ"32;01m"
COL_YELLOW=$ESC_SEQ"33;01m"
COL_BLUE=$ESC_SEQ"34;01m"
COL_MAGENTA=$ESC_SEQ"35;01m"
COL_CYAN=$ESC_SEQ"36;01m"

echo;
echo -e "$COL_CYAN════════════════════════════════════════════════$COL_RESET"
echo -e "$COL_GREEN Skrypt Instalacyjny Temspeak3$COL_RESET"
echo -e "$COL_YELLOW Skrypt stworzony przez Bergthor/Sprint012/Vat_Design$COL_RESET"
echo -e "$COL_RED Skrypt Posiada wersję takie jak [3.7.0][3.7.1][3.8.0][3.9.1]$COL_RESET"
echo -e "$COL_BLUE ZAKAZ PRZERABIANIA SKRYPTU I USUWANIA AUTORA!$COL_RESET"
echo -e "$COL_YELLOW Dalsze Aktualizacje związane z wersjami TeamSpeak3 Będą wykonywane!$COL_RESET"
echo -e "$COL_RED Wersja Skryptu 2.0 [18.09.2019r]$COL_RESET"
echo -e "$COL_GREEN Mój Teamspeak3 EnergySpeak.pl$COL_RESET"
echo -e "$COL_CYAN════════════════════════════════════════════════$COL_RESET"
echo;
echo -e "$COL_RED Instalator TeamSpeak3 oto wersje na ten moment$COL_RESET"
echo;

echo -e "$COL_BLUE[*==*1*==*] Wersja 3.7.0$COL_RESET"
echo -e "$COL_BLUE[*==*2*==*] Wersja 3.7.1$COL_RESET"
echo -e "$COL_BLUE[*==*3*==*] Wersja 3.8.0$COL_RESET"
echo -e "$COL_BLUE[*==*4*==*] Wersja 3.9.1$COL_RESET"
echo -e "$COL_RED[*==*0*==*] Wyjście$COL_RESET"


echo -e " "
read wersion

3.7.0()
{

clear
echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Aktualizowanie Maszyny VPS/DEDYKCOL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
clear
apt-get update
apt-get upgrade -y
clear
echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Instalowanie wersji 3.7.0 - w toku!COL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
clear
cd /home
wget http://dl.4players.de/ts/releases/3.7.0/teamspeak3-server_linux_amd64-3.7.0.tar.bz2 -O ts3server
tar -zxvf ts3server
tar -jxvf ts3server
cd teamspeak3-server_linux_amd64
touch .ts3server_license_accepted
chmod +x ts3server_startscript.sh
./ts3server_startscript.sh start
echo
echo
echo

echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Instalacja 3.7.0 - Zakończona!COL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
}


3.7.1()
{

clear
echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Aktualizowanie Maszyny VPS/DEDYKCOL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
clear
apt-get update
apt-get upgrade -y
clear
echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Instalowanie wersji 3.7.1 - w toku!COL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
clear
cd /home
wget http://dl.4players.de/ts/releases/3.7.1/teamspeak3-server_linux_amd64-3.7.1.tar.bz2 -O ts3server
tar -zxvf ts3server
tar -jxvf ts3server
cd teamspeak3-server_linux_amd64
touch .ts3server_license_accepted
chmod +x ts3server_startscript.sh
./ts3server_startscript.sh start
echo
echo
echo

echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Instalacja 3.7.1 - Zakończona!COL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
}

3.8.0()
{

clear
echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Aktualizowanie Maszyny VPS/DEDYKCOL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
clear
apt-get update
apt-get upgrade -y
clear
echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Instalowanie wersji 3.8.0 - w toku!COL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
clear
cd /home
wget http://dl.4players.de/ts/releases/3.8.0/teamspeak3-server_linux_amd64-3.8.0.tar.bz2 -O ts3server
tar -zxvf ts3server
tar -jxvf ts3server
cd teamspeak3-server_linux_amd64
touch .ts3server_license_accepted
chmod +x ts3server_startscript.sh
./ts3server_startscript.sh start
echo
echo
echo

echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Instalacja 3.8.0 - Zakończona!COL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
}

3.9.1()
{

clear
echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Aktualizowanie Maszyny VPS/DEDYKCOL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
clear
apt-get update
apt-get upgrade -y
clear
echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Instalowanie wersji 3.9.1 - w toku!COL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
clear
cd /home
wget http://dl.4players.de/ts/releases/3.9.1/teamspeak3-server_linux_amd64-3.9.1.tar.bz2 -O ts3server
tar -zxvf ts3server
tar -jxvf ts3server
cd teamspeak3-server_linux_amd64
touch .ts3server_license_accepted
chmod +x ts3server_startscript.sh
./ts3server_startscript.sh start
echo
echo
echo

echo -e "$COL_CYAN**************************************$COL_RESET"
echo -e "$COL_YELLOW Instalacja 3.9.1 - Zakończona!COL_RESET"
echo -e "$COL_CYAN**************************************$COL_RESET"
}

if [[ "$wersion" == "1" ]]; then
	3.7.0
elif [[ "$wersion" == "2" ]]; then
	3.7.1
elif [[ "$wersion" == "3" ]]; then
	3.8.0
elif [[ "$wersion" == "4" ]]; then
	3.9.1
elif [[ "$wersion" == "0" ]]; then
	exit;
fi
